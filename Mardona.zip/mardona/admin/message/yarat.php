<?php
include("../connection.php");
if (isset($_POST['saqlash'])) {
    $name = $_POST['name'];
    $email =$_POST['email'];
    $subject =$_POST['subject'];
    $message =$_POST['message'];
  
    $sql = "INSERT INTO message(name, email, subject, message) 
    VALUES ('".addslashes($name)."','".addslashes($email)."', '".addslashes($subject)."','".addslashes($message)."' );";
     if ($connection->query($sql)) {
      header('Location:../../index.html');
    } else echo 'xato!' . $connection->error;
  
}

?>
