<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
   <h1>Xabarlar jadvali</h1>



   <html>
    <head>
</head>
<body>
<table class="table table-hover">
        <thead>
        <tr>
            <th>ID</th>
            <th>Ismi</th>
            <th>Emeil</th>
            <th>Mavz</th>
            <th>Xabari</th>
            <th>o'chirish</th>
        </tr>
        </thead>
        <tbody>
        <?php 
        include('../connection.php');
        $sql = "SELECT * FROM message";
        $result = $connection->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc())
            {
                ?>
                <tr>
<!--                    <td>--><?php //echo $row['id']?><!--</td>-->
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['email']?></td>
                    <td><?php echo $row['subject']?></td>
                    <td><?php echo $row['message']?></td>
                    </td>
                    <td>
                        <form action="delete.php" method="post">
                            <input type="hidden" name="id" value="<?php echo($row['id'])?>">
                            <button type="submit" class="btn btn-danger">O'chirish</button>

                        </form>
                    </td>
                  
                </tr>
            <?php 
        }
    }
        ?>
        </tbody>
    </table>




</body>
<html>

</body>
</html>