<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mardona';

$connection = new mysqli($host, $username, $password, $dbname);
if($connection->connect_error){
    die("Ulanishda hatolik" . $connection->connect_error);
}
else{
    echo "  ";
}

?>